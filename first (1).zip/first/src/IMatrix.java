public interface IMatrix<T> {
    T getNumberFromMatrix(int rowIndex, int columnIndex);
    IMatrix<T> setNumberToMatrix(T number, int rowIndex, int columnIndex) throws Exception;
    String getColumnFromMatrix(int columnIndex);
    String getRowFromMatrix(int rowIndex);
    int[] getSizeFromMatrix();
}
