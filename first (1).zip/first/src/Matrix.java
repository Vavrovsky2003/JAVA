import java.util.Arrays;

public class Matrix implements IMatrix<Double>, ObernenaMatrix{
    private final double[][] matrix;

    public Matrix(){
        matrix = new double[0][0];
    }
    public Matrix(int rowNumbers, int columnNumbers){
        matrix = new double[rowNumbers][columnNumbers];
    }
    public Matrix(Matrix matrix1){
        matrix = matrix1.matrix.clone();
    }

    @Override
    public Double getNumberFromMatrix(int rowIndex, int columnIndex) {
        return matrix[rowIndex][columnIndex];
    }

    @Override
    public IMatrix<Double> setNumberToMatrix(Double number, int rowIndex, int columnIndex) throws Exception {
        matrix[rowIndex][columnIndex] = number;
        return this;
    }

    @Override
    public String getColumnFromMatrix(int columnIndex) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i=0; i<getSizeFromMatrix()[0];i++)
            stringBuilder.append(matrix[i][columnIndex]).append('\n');
        return String.valueOf(stringBuilder);
    }

    @Override
    public String getRowFromMatrix(int rowIndex) {
        return Arrays.toString(matrix[rowIndex]);
    }

    @Override
    public int[] getSizeFromMatrix() {
        return new int[]{matrix.length, matrix[0].length};
    }

    @Override
    public IMatrix<Double> getObernenuMatrix() throws Exception {
        //https://ua.onlinemschool.com/math/assistance/matrix/inverse/?oms_all=a%3d%7b%7b1,3%7d,%7b2,4%7d%7d
        if (getSizeFromMatrix()[0]!=getSizeFromMatrix()[1]) throw new Exception();
        double[] Vector = new double[getSizeFromMatrix().length];
        Matrix copy = new Matrix(this);
        Arrays.fill(Vector, 1);
        Matrix ObernenaMatrix = (Matrix) makeDiagonalMatrix(Vector);
        for (int i=0;i<getSizeFromMatrix()[0];i++){
            for (int j=0;j<getSizeFromMatrix()[0];j++)
                if (j!=i) {
                    double coef = copy.matrix[j][i] / copy.matrix[i][i];
                    ObernenaMatrix.rowMinusRow(i, j, coef);
                    copy.rowMinusRow(i, j, coef);
                }
            ObernenaMatrix.divideRow(i,matrix[i][i]);
        }
        return ObernenaMatrix;
    }

    private void rowMinusRow(int row1, int row2, double num){
        for (int i=0;i<getSizeFromMatrix()[0];i++)
            matrix[row2][i]-=matrix[row1][i]*num;
    }

    private void divideRow(int row, double num){
        for (int i=0;i<getSizeFromMatrix()[0];i++)
            matrix[row][i]/=num;
    }

    public static IMatrix<Double> makeDiagonalMatrix(double[] Vector) throws Exception {
        Matrix matrix1= new Matrix(Vector.length, Vector.length);
        for (int i=0;i< Vector.length;i++)
            matrix1.setNumberToMatrix(Vector[i],i,i);
        return matrix1;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (double[] doubles: matrix)
            stringBuilder.append(Arrays.toString(doubles)).append('\n');
        return String.valueOf(stringBuilder);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Matrix matrix1 = (Matrix) o;
        return Arrays.deepEquals(matrix, matrix1.matrix);
    }

    @Override
    public int hashCode() {
        return Arrays.deepHashCode(matrix);
    }
}
