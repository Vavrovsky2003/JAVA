import java.util.Arrays;

public class GenericMatrix<T> implements IMatrix<T>{
    private final T[][] matrix;

    public GenericMatrix(T[][] matrixArr){
        matrix =matrixArr.clone();
    }

    public GenericMatrix(GenericMatrix<T> matrix1){
        matrix = matrix1.matrix.clone();
    }

    @Override
    public T getNumberFromMatrix(int rowIndex, int columnIndex) {
        return matrix[rowIndex][columnIndex];
    }

    @Override
    public IMatrix<T> setNumberToMatrix(T number, int rowIndex, int columnIndex) throws Exception {
        matrix[rowIndex][columnIndex] = number;
        return this;
    }

    @Override
    public String getColumnFromMatrix(int columnIndex) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i=0; i<getSizeFromMatrix()[0];i++)
            stringBuilder.append(matrix[i][columnIndex]).append('\n');
        return String.valueOf(stringBuilder);
    }

    @Override
    public String getRowFromMatrix(int rowIndex) {
        return Arrays.toString(matrix[rowIndex]);
    }

    @Override
    public int[] getSizeFromMatrix() {
        return new int[]{matrix.length, matrix[0].length};
    }


    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (T[] doubles: matrix)
            stringBuilder.append(Arrays.toString(doubles)).append('\n');
        return String.valueOf(stringBuilder);
    }
}
