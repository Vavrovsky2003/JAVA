public interface ObernenaMatrix {
    public IMatrix<Double> getObernenuMatrix() throws Exception;
}
