public class MatrixImmutable extends Matrix{
    @Override
    public IMatrix<Double> setNumberToMatrix(Double number, int rowIndex, int columnIndex) throws Exception {
        throw new Exception("Immutable matrix cannot change");
    }
}
