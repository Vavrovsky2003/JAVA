public class Main {
    public static void main(String[] args) throws Exception {
        Matrix matrix = new Matrix(2,2);
        matrix.setNumberToMatrix(1.0,0,0);
        matrix.setNumberToMatrix(2.0,1,0);
        matrix.setNumberToMatrix(3.0,0,1);
        matrix.setNumberToMatrix(4.0,1,1);
        System.out.println(matrix);
        System.out.println(matrix.getObernenuMatrix());

        GenericMatrix<String> stringGenericMatrix = new GenericMatrix<>(new String[][]{{"Heelo", "World"},{"Hello", "World"}});
        System.out.println(stringGenericMatrix);
    }
}